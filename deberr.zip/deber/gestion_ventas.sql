/*
 Navicat Premium Data Transfer

 Source Server         : conexion_servidor_local
 Source Server Type    : MariaDB
 Source Server Version : 100432
 Source Host           : localhost:3306
 Source Schema         : gestion de venta

 Target Server Type    : MariaDB
 Target Server Version : 100432
 File Encoding         : 65001

 Date: 27/01/2024 01:28:14
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for cat
-- ----------------------------
DROP TABLE IF EXISTS `cat`;
CREATE TABLE `cat`  (
  `cod_categoria` int(255) NOT NULL AUTO_INCREMENT,
  `nom_cat` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`cod_categoria`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cat
-- ----------------------------
INSERT INTO `cat` VALUES (1, 'Bebidas');
INSERT INTO `cat` VALUES (2, 'Carnicos');
INSERT INTO `cat` VALUES (3, 'lacteos');
INSERT INTO `cat` VALUES (4, 'gramineas');
INSERT INTO `cat` VALUES (5, 'verduras y frutas');

-- ----------------------------
-- Table structure for producto
-- ----------------------------
DROP TABLE IF EXISTS `producto`;
CREATE TABLE `producto`  (
  `cod_producto` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `nom_producto` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `precio` decimal(10, 2) NULL DEFAULT NULL,
  `fecha_elab` date NULL DEFAULT NULL,
  `fecha_cad` date NULL DEFAULT NULL,
  `cantidad` int(11) NULL DEFAULT NULL,
  `cod_categoria` int(150) NULL DEFAULT NULL,
  PRIMARY KEY (`cod_producto`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of producto
-- ----------------------------
INSERT INTO `producto` VALUES ('', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `producto` VALUES ('0001', 'pera', 21.00, '2024-01-10', '2024-02-03', 5, 0);
INSERT INTO `producto` VALUES ('00012', 'pera', 21.00, '2024-01-10', '2024-02-03', 5, 0);
INSERT INTO `producto` VALUES ('001', 'arroz', 0.50, '2024-01-26', '2024-02-04', 100, 4);
INSERT INTO `producto` VALUES ('002', 'coca cola', 1.00, '2024-01-26', '2024-02-27', 200, 1);
INSERT INTO `producto` VALUES ('100', 'fresa', 23.00, '2024-01-25', '2023-12-29', 2, 0);
INSERT INTO `producto` VALUES ('1002', 'sandia', 23.00, '2024-01-25', '2023-12-29', 2, 0);
INSERT INTO `producto` VALUES ('123', 'verde', 12.00, '2024-01-12', '2024-02-04', 1, 0);
INSERT INTO `producto` VALUES ('1233', 'verde', 12.00, '2024-01-12', '2024-02-04', 1, 0);
INSERT INTO `producto` VALUES ('12334', 'verde', 12.00, '2024-01-12', '2024-02-04', 5, 0);
INSERT INTO `producto` VALUES ('22', 'verde', 23.00, '2024-01-25', '2023-12-29', 1, 0);
INSERT INTO `producto` VALUES ('2224', 'fresa', 23.00, '2024-01-25', '2023-12-29', 2, 0);

-- ----------------------------
-- View structure for vista_b
-- ----------------------------
DROP VIEW IF EXISTS `vista_b`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `vista_b` AS select `cat`.`nom_cat` AS `nom_cat`,`producto`.`cod_categoria` AS `cod_categoria`,`producto`.`cantidad` AS `cantidad`,`producto`.`fecha_cad` AS `fecha_cad`,`producto`.`fecha_elab` AS `fecha_elab`,`producto`.`precio` AS `precio`,`producto`.`nom_producto` AS `nom_producto`,`producto`.`cod_producto` AS `cod_producto` from (`cat` join `producto` on(`cat`.`cod_categoria` = `producto`.`cod_categoria`));

SET FOREIGN_KEY_CHECKS = 1;
