<?php
// Include the database connection file
include("config/conexion.php");

// Check if the product ID is provided in the URL
if(isset($_GET["id"]) && !empty($_GET["id"])) {
    // Sanitize the product ID to prevent SQL injection
    $id = mysqli_real_escape_string($conn, $_GET["id"]);

    // Retrieve the product information from the database
    $selectQuery = "SELECT * FROM producto WHERE cod_producto = '$id'";
    $result = $conn->query($selectQuery);

    if ($result->num_rows > 0) {
        // Fetch product details
        $row = $result->fetch_assoc();
        $cod_producto = $row["cod_producto"];
        $nom_producto = $row["nom_produc"];
        $precio = $row["precio"];
        $fecha_elab = $row["fecha_elab"];
        $fecha_cad = $row["fecha_cad"];
        $cantidad = $row["cantidad"];
        $cod_categoria = $row["cod_categoria"];

        // Display the edit form with pre-filled data
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Edición de Producto</title>
            <link rel="stylesheet" href="css/bootstrap.min.css">
        </head>
        <body>
            <div class="container">
                <h2 class="text-center my-4">Edición de Producto</h2>
                <form action="actualizar_producto.php" method="POST">
                    <input type="hidden" name="cod_producto" value="<?php echo $cod_producto; ?>">
                    <div class="form-group">
                        <label for="nom_producto">Nombre de Producto:</label>
                        <input type="text" class="form-control" name="nom_producto" value="<?php echo $nom_producto; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="precio">Precio:</label>
                        <input type="text" class="form-control" name="precio" value="<?php echo $precio; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="fecha_elab">Fecha de Elaboración:</label>
                        <input type="date" class="form-control" name="fecha_elab" value="<?php echo $fecha_elab; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="fecha_cad">Fecha de Caducidad:</label>
                        <input type="date" class="form-control" name="fecha_cad" value="<?php echo $fecha_cad; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="cantidad">Cantidad:</label>
                        <input type="number" class="form-control" name="cantidad" value="<?php echo $cantidad; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="cod_categoria">Código de Categoría:</label>
                        <input type="text" class="form-control" name="cod_categoria" value="<?php echo $cod_categoria; ?>" required>
                    </div>
                    <div class="text-center mt-4">
                        <input type="hidden" name="id" value="<?php echo $cod_producto; ?>">
                        <button type="submit" class="btn btn-primary">Editar Producto</button>
                    </div>
                </form>
            </div>
        </body>
        </html>
        <?php
    } else {
        echo "No se encontró ningún producto con el ID proporcionado.";
    }
    // Close the database connection
    mysqli_close($conn);
} else {
    // If no product ID is provided in the URL, display an error message or redirect as needed
    echo "No se proporcionó ningún ID de producto para editar.";
}
?>
